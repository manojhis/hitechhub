<?php 
	 // Silence is golden.