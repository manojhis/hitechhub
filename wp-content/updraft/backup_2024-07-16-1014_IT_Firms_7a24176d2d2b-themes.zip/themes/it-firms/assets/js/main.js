document.addEventListener('DOMContentLoaded', function() {
    var navItems = document.querySelectorAll('.nav-item.dropdown');
    navItems.forEach(function(navItem) {
        var navLink = navItem.querySelector('.nav-link');
        navLink.addEventListener('click', function(e) {
            e.preventDefault();
            // Remove active class from all nav-items
            navItems.forEach(function(item) {
                item.classList.remove('show');
            });
            // Toggle show class on the clicked nav-item
            navItem.classList.toggle('show');
        });
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-item')) {
            // Remove show class from all nav-items if clicked outside
            navItems.forEach(function(item) {
                item.classList.remove('show');
            });
        }
    });
});

// ---- on hover add class of mega menu-----
document.addEventListener('DOMContentLoaded', function () {
    const navLinks = document.querySelectorAll('.big-nav .nav .nav-link');
    const tabContent = document.querySelectorAll('.big-nav .tab-content .tab-pane');

    navLinks.forEach(link => {
        link.addEventListener('mouseover', function () {
            // Remove active class from all nav-links and tab-panes
            navLinks.forEach(nav => nav.classList.remove('active'));
            tabContent.forEach(tab => tab.classList.remove('show', 'active'));
            // Add active class to the hovered nav-link and corresponding tab-pane
            this.classList.add('active');
            const targetId = this.getAttribute('data-bs-target');
            const targetTab = document.querySelector(targetId);
            targetTab.classList.add('show', 'active');
        });
    });
});

// *************** Read More & Read Less Js **************
// document.addEventListener('DOMContentLoaded', function() {
//     function AddReadMore(wordLmt, readMoreTxt, selector) {
//         document.querySelectorAll(selector).forEach(function(element) {
//             if (element.classList.contains("read-more-initialized")) return;
//             var allstr = element.textContent.trim();
//             var words = allstr.split(/\s+/);
//             if (words.length > wordLmt) {
//                 var firstSet = words.slice(0, wordLmt).join(" ");
//                 var secdHalf = words.slice(wordLmt).join(" ");
//                 var strtoadd = firstSet + "<span class='second-section' style='display:none;'>" + secdHalf + "</span><span class='read-more' title='Click to Show More'>" + readMoreTxt + "</span>";

//                 element.innerHTML = strtoadd;
//                 element.classList.add("read-more-initialized");
//             }
//         });
//         document.querySelectorAll(selector + " .read-more").forEach(function(element) {
//             element.addEventListener("click", function() {
//                 var parent = this.closest(selector);
//                 var secondSection = parent.querySelector(".second-section");
//                 if (secondSection) {
//                     secondSection.style.display = "inline";
//                     this.style.display = "none";
//                 }
//             });
//         });
//     }
//     AddReadMore(65, " ...read more", ".add-read-more");
//     AddReadMore(85, " ...read more", ".company-list-body .add-read-more");
// });



// *************** Read More & Read Less Js **************
// document.addEventListener('DOMContentLoaded', function() {
//     function AddReadMore(wordLmt, readMoreTxt, readLessTxt, selector) {
//         // Traverse all selectors with this class and manipulate HTML part to show Read More
//         document.querySelectorAll(selector).forEach(function(element) {
//             if (element.querySelector(".first-section")) return;

//             var allstr = element.textContent;
//             var words = allstr.split(/\s+/);
//             if (words.length > wordLmt) {
//                 var firstSet = words.slice(0, wordLmt).join(" ");
//                 var secdHalf = words.slice(wordLmt).join(" ");
//                 var strtoadd = firstSet + "<span class='second-section'>" + secdHalf + "</span><span class='read-more'  title='Click to Show More'>" + readMoreTxt + "</span>";
//                 if (readLessTxt) {
//                     strtoadd += "<span class='read-less' title='Click to Show Less'>" + readLessTxt + "</span>";
//                 }
//                 element.innerHTML = strtoadd;
//             }
//         });
//         document.querySelectorAll(selector + " .read-more, " + selector + " .read-less").forEach(function(element) {
//             element.addEventListener("click", function() {
//                 var parent = this.closest(selector);
//                 parent.classList.toggle("show-less-content");
//                 parent.classList.toggle("show-more-content");
//             });
//         });
//     }

//     AddReadMore(65, " ...read more", " read less", ".add-read-more");
//     AddReadMore(85, ".company-list-body .add-read-more");
// });

// /* charachter limit */
document.addEventListener('DOMContentLoaded', function() {
    function AddReadMore(charLimit, readMoreTxt, readLessTxt, selector) {
        // Traverse all selectors with this class and manipulate HTML part to show Read More
        document.querySelectorAll(selector).forEach(function(element) {
            if (element.querySelector(".first-section")) return;

            var allstr = element.textContent.trim();
            if (allstr.length > charLimit) {
                var visibleText = allstr.substring(0, charLimit);
                var hiddenText = allstr.substring(charLimit);
                var strtoadd = visibleText + "<span class='second-section' style='display:none;'>" + hiddenText + "</span><span class='read-more' title='Click to Show More'>" + readMoreTxt + "</span>";
                if (readLessTxt) {
                    strtoadd += "<span class='read-less' title='Click to Show Less' style='display:none;'>" + readLessTxt + "</span>";
                }
                element.innerHTML = strtoadd;
            }
        });
        document.querySelectorAll(selector + " .read-more, " + selector + " .read-less").forEach(function(element) {
            element.addEventListener("click", function() {
                var parent = this.closest(selector);
                var secondSection = parent.querySelector(".second-section");
                var readMoreBtn = parent.querySelector(".read-more");
                var readLessBtn = parent.querySelector(".read-less");

                if (secondSection.style.display === "none") {
                    secondSection.style.display = "inline";
                    readMoreBtn.style.display = "none";
                    if (readLessBtn) readLessBtn.style.display = "inline";
                } else {
                    secondSection.style.display = "none";
                    readMoreBtn.style.display = "inline";
                    if (readLessBtn) readLessBtn.style.display = "none";
                }
            });
        });
    }

    AddReadMore(450, " ...read more", " read less", ".add-read-more");
});

// document.addEventListener('DOMContentLoaded', function() {
//     function AddReadMore(maxHeight, readMoreTxt, readLessTxt, selector) {
//         // Traverse all selectors with this class and manipulate HTML part to show Read More
//         document.querySelectorAll(selector).forEach(function(element) {
//             if (element.querySelector(".first-section")) return;

//             var elementHeight = element.scrollHeight; // Total height of the element's content
//             if (elementHeight > maxHeight) {
//                 element.style.maxHeight = maxHeight + 'px';
//                 element.classList.add('collapsed'); // Add a class to track collapsed state

//                 var readMoreHtml = "<span class='read-more' title='Click to Show More'>" + readMoreTxt + "</span>";
//                 if (readLessTxt) {
//                     readMoreHtml += "<span class='read-less' title='Click to Show Less' style='display:none;'>" + readLessTxt + "</span>";
//                 }

//                 // Append read more HTML
//                 var readMoreContainer = document.createElement('div');
//                 readMoreContainer.classList.add('read-more-container');
//                 readMoreContainer.innerHTML = readMoreHtml;
//                 element.parentNode.insertBefore(readMoreContainer, element.nextSibling);

//                 // Event listener for read more button
//                 readMoreContainer.querySelector('.read-more').addEventListener('click', function() {
//                     element.classList.toggle('collapsed');
//                     var isCollapsed = element.classList.contains('collapsed');
//                     if (isCollapsed) {
//                         element.style.maxHeight = maxHeight + 'px';
//                         readMoreContainer.querySelector('.read-more').style.display = 'none';
//                         readMoreContainer.querySelector('.read-less').style.display = 'inline';
//                     } else {
//                         element.style.maxHeight = '';
//                         readMoreContainer.querySelector('.read-more').style.display = 'inline';
//                         readMoreContainer.querySelector('.read-less').style.display = 'none';
//                     }
//                 });

//                 // Event listener for read less button (if exists)
//                 var readLessBtn = readMoreContainer.querySelector('.read-less');
//                 if (readLessBtn) {
//                     readLessBtn.addEventListener('click', function() {
//                         element.classList.toggle('collapsed');
//                         element.style.maxHeight = maxHeight + 'px';
//                         readMoreContainer.querySelector('.read-more').style.display = 'none';
//                         readMoreContainer.querySelector('.read-less').style.display = 'inline';
//                     });
//                 }
//             }
//         });
//     }

//     AddReadMore(100, " ...read more", " read less", ".add-read-more");
// });
