<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package IT_Firms
 */

get_header();
?>
<link rel="stylesheet" href="<?php echo IT_HIPL_THEME_DIR;?>/assets/css/company-list-page.min.css">

<main id="primary" class="site-main">
	<!-- Banner Section Start -->
	<section class="banner-section comapny-list">
	    <div class="container">
	        <div class="row align-items-center">
	            <div class="col-lg-8 col-sm-12 col-12">
	                <div class="banner-content">
	                    <h1 class="banner-title text-white"><?= ucfirst(get_the_title()) ?></h1>
	                    <div class="sub-title">THE BEST OF <?php echo date('M Y'); ?></div>
	                </div>
	            </div>
				<div class="col-lg-4 col-sm-12 col-12">
	                <div class="comapny-list-img text-lg-start text-center">
	                    <img src="<?php echo IT_HIPL_THEME_DIR;?>/assets/images/banner-img/company-list-banner-img.svg" alt="company">
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- Banner Section End -->

    <!-- Contant Section Start -->
    <section class="content-banner">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-12">
                    <h2 class="content-banner-title"><?= esc_html(get_post_meta(get_the_ID(), 'sub_heading', true)) ?></h2>
                    <p class="add-read-more show-less-content"><?= get_the_content() ?></p>
                </div>
            </div>
        </div>
    </section>
    <!-- Contant Section End -->

	<!-- Company List Card Start -->
	<section class="company-list-card ">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-12">
					<div class="company-reating">
						<?php 
						while(have_posts()) :
							the_post();
							
							$postid 			= 	get_the_ID();
							$post_type 			= 	get_post_type();
							if($post_type == 'post'){
								$industries 		= 	get_post_meta($postid, 'industry', true);
								$selectedindustries = 	[];
								if(!empty($industries) && is_array($industries)){
									$industriesQueries  = 	['relation'  =>  'OR',];
									foreach($industries as $ind){
										$industriesQueries[] 		= [
											'key' 		=> 'industry',
											'value' 	=> $ind,
											'compare' 	=> 'LIKE'
										];
									}
								}
								$industriesString = (!empty($selectedindustries) && is_array($selectedindustries)) ? implode(',', $selectedindustries) : $selectedindustries;
								$location 			= 	get_post_meta($postid, 'location', true);
								$selectedlocation 	= 	[];
								if(!empty($location) && is_array($location)){
									$locationQueries  = 	['relation'  =>  'OR',];
									foreach($location as $loc){
										$locationQueries[] 		= [
											'key' 		=> 'location',
											'value' 	=> $loc,
											'compare' 	=> 'LIKE'
										];
									}
								}
								$locationString = (!empty($selectedlocation) && is_array($selectedlocation)) ? implode(',', $selectedlocation) : $selectedlocation;
								$services 			= 	get_post_meta($postid, 'services', true);
								$selectedservices 	= 	[];
								if(!empty($services) && is_array($services)){
									$servicesQueries  = 	['relation'  =>  'OR',];
									foreach($services as $serv){
										$servicesQueries[] 		= [
											'key' 		=> 'services',
											'value' 	=> $serv,
											'compare' 	=> 'LIKE'
										];
									}
								}
								$servicesString = (!empty($selectedservices) && is_array($selectedservices)) ? implode(',', $selectedservices) : $selectedservices;
								
								$paged  = (get_query_var('paged')) ? get_query_var('paged') : 1;
								
								$args   = [
									'post_type' 		=> 	'agency',
									'post_status' 		=> 	'publish',
									'posts_per_page'	=>	-1,
									'orderby'			=>	'date',
									'order'				=>	'DESC',
								];
				
								$meta_query = ['relation' => 'AND',];
				
								if(isset($industriesQueries) && !empty($industriesQueries)){
									$meta_query[] = $industriesQueries;
								}
								if(isset($locationQueries) && !empty($locationQueries)){
									$meta_query[] = $locationQueries;
								}
								if(isset($servicesQueries) && !empty($servicesQueries)){
									$meta_query[] = $servicesQueries;
								}
				
								if(!empty($meta_query)){
									$args['meta_query'] = $meta_query;
								}
								$companies = (!empty(get_posts($args))) ? get_posts($args) : [];

								if(have_rows('add_companies')){
									while(have_rows('add_companies')): the_row();
										$select_company          	=   get_sub_field('select_company');
										$position    				=   (int) get_sub_field('position');
										$expire_membership_date    	=   get_sub_field('expire_membership_date');
										$expiredate 				= 	date_create_from_format('d/m/Y', $expire_membership_date)->format('Y-m-d');
										$currentDate 				= 	date('Y-m-d');
										if($expiredate >= $currentDate){
											$selectedCompID 	= 	$select_company->ID;
											$companies_ids 		= 	array_column($companies, 'ID');

											if(in_array($selectedCompID, $companies_ids)){

												$companies = array_filter($companies, function ($post) use ($selectedCompID){
													return $post->ID !== $selectedCompID;
												});

												$order_number = $position - 1;
												array_splice($companies, $order_number, 0, array($select_company));

											}else{

												$order_number = $position - 1;
												array_splice($companies, $order_number, 0, array($select_company));

											}
										}
									endwhile;
								}

								$number_of_comp 	= 	get_post_meta($postid, 'number_of_companies', true);
								$comp_limit 		= 	(!empty($number_of_comp)) ? (int)$number_of_comp : '';
								if(!empty($comp_limit)){
									$companies = array_slice($companies, 0, $comp_limit);
								}
								if(!empty($companies)){
									$company_count = count($companies);
									foreach($companies as $key => $comp){
										$compID = $comp->ID;
										$company_logo 			= (!empty(get_post_meta($compID, 'company_logo', true))) ? get_post_meta($compID, 'company_logo', true) : site_url().'/wp-content/themes/it-firms/assets/images/company-logo.png';
										 
										$sales_email 			= (!empty(get_post_meta($compID, 'sales_email', true))) ? get_post_meta($compID, 'sales_email', true) : '';
										$admin_contact_phone 	= (!empty(get_post_meta($compID, 'admin_contact_phone', true))) ? get_post_meta($compID, 'admin_contact_phone', true) : '';
										if(!empty($admin_contact_phone)){
											$formatted_number = '+1-' . substr($admin_contact_phone, 0, 3) . '-' . substr($admin_contact_phone, 3, 3) . '-' . substr($admin_contact_phone, 6);
										}else{
											$formatted_number = '';
										}
										$total_employees 	= 	(!empty(get_post_meta($compID, 'total_employees', true))) ? get_post_meta($compID, 'total_employees', true) : '';
										$founding_year 		= 	(!empty(get_post_meta($compID, 'founding_year', true))) ? get_post_meta($compID, 'founding_year', true) : '';
										$purse 				= 	(!empty(get_post_meta($compID, 'purse', true))) ? get_post_meta($compID, 'purse', true) : '';
										$rate 				= 	(!empty(get_post_meta($compID, 'rate', true))) ? get_post_meta($compID, 'rate', true) : '';
										$company_website 	= 	(!empty(get_post_meta($compID, 'company_website', true))) ? get_post_meta($compID, 'company_website', true) : '';
										$location 			= 	(!empty(get_post_meta($compID, 'location', true))) ? get_post_meta($compID, 'location', true) : [];

										$agency_industry   	= 	(!empty(get_post_meta($compID, 'industry', true))) ? get_post_meta($compID, 'industry', true) : [];
										$agency_services    = 	(!empty(get_post_meta($compID, 'services', true))) ? get_post_meta($compID, 'services', true) : [];

										?>

										<?php if (($key == 1 && $company_count <= 2) || ($key == 2 && $company_count > 2)) { ?>
											<div class="company-item">
												<div class="company-side get-conntect">
													<div class="connetct-body">
														<div class="comapny-details d-flex align-items-sm-center flex-md-row flex-column">
															<div class="conntect-img"><img src="<?php echo IT_HIPL_THEME_DIR;?>/assets/images/icon/draft.svg" alt="conntect"></div>
															<div class="company-name">
																<h3 class="company-title">Get Connected With A Company For Free</h3>
																<p class="m-0">Tell us about your project, and we'll match you with vetted companies that meet your requirements.</p>
															</div>
														</div>
														<a href="/find-an-agency" class="btn btn-theme1">GET STARTED</a>
													</div>
												</div>
											</div>
										<?php } ?>

											<div class="company-item">
												<div class="company-side">
													<div class="comapny-details d-flex align-items-sm-center flex-sm-row flex-column">
														<div class="company-logo"><img src="<?= $company_logo ?>" alt="HIPL"></div>
														<div class="company-name">
															<h3 class="company-title"><?= ucfirst($comp->post_title) ?></h3>
															<p class="m-0">Empowering Digital Commerce Transformation</p>
														</div>
													</div>
													<div class="company-list-body">
														<p class="add-read-more show-less-content"><?php echo $comp->post_content; ?></p>
														<div class="discription flex-xl-row flex-column align-items-xl-center">
															<div class="categorie-list">
																<h4 class="discription-title">Industry</h4>
																<ul class="industry-list list"><?php
																if (!empty($agency_industry) && is_array($agency_industry)) {
																	foreach($agency_industry as $industry){ 
																		$industryAray = get_term($industry);
																		$term_id = $industryAray->term_id;
																		$icon = get_field('icon', 'term_' . $term_id);
																		if($icon) {
																			?>
																			<li>
																				<a class="tags"><img src="<?= $icon['url'] ?>" alt="education"></a>
																			</li><?php 
																		}
																	}
																} ?>
																</ul>
															</div>
															<div class="categorie-list">																	
																<?php 
																if(!empty($location) && is_array($location)){
																	?>
																	<h4 class="discription-title">Location</h4>
																	<ul class="list">
																		<?php
																		foreach($location as $loc){
																			if (get_term($loc)->parent == 0) {
																				$loctionAray = get_term($loc);
																				?>
																				<li><a class="tags fw-medium"><?= $loctionAray->name ?></a></li>
																				<?php
																			}
																		}
																		?>
																	</ul>
																	<?php
																}
																?>
															</div>
														</div>
													 
													</div>
												</div>
												<div class="details-side">
													<ul class="card-details">
														<li>
															<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/bulding.svg" alt="bulding"></span>
															Founded <?= $founding_year ?>
														</li>
														<li>
															<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/dollor.svg" alt="dollor"></span>
															<?= $purse ?>/hr
														</li>
														<li>
															<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/users.svg" alt="users"></span>
															<?= $total_employees ?>
														</li>
														<li>
															<?php $first_term = $agency_services[0];
															$term = get_term($first_term);
															$term_name = $term->name;
															$term_link = get_term_link($term); ?>
															<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/tag-fill.svg" alt="tag"></span>
															<a href="<?= esc_url($term_link) ?>"><?= esc_html( $term_name ) ?></a>
														</li>
														<?php 
														if(!empty($sales_email)){
															?>
															<li>
																<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/project-budget.svg" alt="project-budget"></span>
																<a href="mailto:<?= $sales_email ?>" class="fw-medium text-decoration-none"><?= $sales_email ?></a>
															</li>
															<?php
														}
														?>
														<li>
															<span class="icon-img"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/tag-fill.svg" alt="tag"></span>
															<a href="tel:<?= $admin_contact_phone ?>" class="fw-semibold text-decoration-none"><?= $admin_contact_phone ?></a>
														</li>
												 
													</ul>
													<div class="contact-button d-flex flex-lg-column flex-md-row flex-column">														 
														<a onclick="trackOutboundLink('<?= $company_website ?>');" href="<?= $company_website ?>?utm_source=<?= site_url() ?>&utm_medium=referral&utm_campaign=<?= get_bloginfo('name') ?>" target="_blank" rel="nofollow" class="btn themebtn w-100 btn-theme1"><span class="btn-icon"><img src="<?= get_stylesheet_directory_uri() ?>/assets/images/icon/globe.svg" alt="globe"></span> Visit Website</a>
													</div>
												</div>
											</div>
										<?php
									}
								}else{
									?>
									<p class="nothingf" style="display:none;">Nothing Found!</p>
									<?php
								}
							}
						endwhile;
						?>
					</div>
				 
				</div>
			</div>
		</div>
	</section>
	<!-- Company List Card End -->

	<div class="content-section section-spacing">
		<div class="container">
			<div class="row">
				<!-- Footer Description -->
				 <div class="col-sm-12 col-12">
					 <div class="allcontent">
						 <div class="item">
							 <?= get_post_meta(get_the_ID(), 'additional_description', true) ?>
						 </div>
						 <?php 
						 if(have_rows('faqs')){
							 ?>
							 <div class="item">
								 <h2 class="title"><?= the_title() ?> FAQs</h2>
								 <div class="accordion" id="accordionExample">
									 <?php 
									 $counter = 1;
									 while(have_rows('faqs')): the_row();
										 if($counter == 1){
											 $faqs_question          =   get_sub_field('faqs_question');
											 $faqs_description    	=   get_sub_field('faqs_description');
											 ?>
											 <div class="accordion-item border-0">
												 <h2 class="accordion-header" id="headingOne">
													 <button class="accordion-button shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
														 <?= $faqs_question ?>
													 </button>
												 </h2>
												 <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
													 <div class="accordion-body">
														 <?= $faqs_description ?>
													 </div>
												 </div>
											 </div>
											 <?php
										 }else{
											 ?>
											 <div class="accordion-item border-0">
												 <h2 class="accordion-header" id="headingTwo">
													 <button class="accordion-button shadow-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
														 <?= $faqs_question ?>
													 </button>
												 </h2>
												 <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
													 <div class="accordion-body">
														 <?= $faqs_description ?>
													 </div>
												 </div>
											 </div>
											 <?php
										 }
										 $counter++;
									 endwhile; 
									 ?>
								 </div>
							 </div>
							 <?php
						 }
						 ?>
						 <div class="item">
							 <h2 class="title">Other Service Providers in India</h2>
							 <div class="service-providers">
								 <ul>
									 <li><a href="javascript:;">.Net Development in India</a></li>
									 <li><a href="javascript:;">Adobe Commerce Development in India</a></li>
									 <li><a href="javascript:;">AI Development in India</a></li>
									 <li><a href="javascript:;">Android App Development in India</a></li>
									 <li><a href="javascript:;">Angular.js Development in India</a></li>
									 <li><a href="javascript:;">App Marketing in India</a></li>
									 <li><a href="javascript:;">B2B Digital Marketing in India</a></li>
									 <li><a href="javascript:;">B2B Ecommerce Development in India</a></li>
									 <li><a href="javascript:;">B2B Website Design in India</a></li>
									 <li><a href="javascript:;">Blockchain Development in India</a></li>
									 <li><a href="javascript:;">Cloud Consulting in India</a></li>
									 <li><a href="javascript:;">Content Marketing in India</a></li>
									 <li><a href="javascript:;">B2B Digital Marketing in India</a></li>
									 <li><a href="javascript:;">B2B Ecommerce Development in India</a></li>
									 <li><a href="javascript:;">B2B Website Design in India</a></li>
									 <li><a href="javascript:;">Blockchain Development in India</a></li>
									 <li><a href="javascript:;">Cloud Consulting in India</a></li>
									 <li><a href="javascript:;">Content Marketing in India</a></li>
								 </ul>
							 </div>
						 </div>
					 </div>
				 </div>
			</div>
		</div>
	</div>
</main><!-- #main -->

<?php
get_sidebar();
get_footer();
?>